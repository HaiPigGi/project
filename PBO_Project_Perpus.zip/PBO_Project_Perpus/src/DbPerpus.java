
import java.sql.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class DbPerpus {

    private String jdbcURL = "jdbc:oracle:thin:@//localhost:1521/xepdb1";//ssid
    //private String jdbcURL = "jdbc:oracle:thin:@//172.23.9.185:1521/orcl";//service
    private String user = "hr";
    private String password = "hr";
    private Connection con = null;
    private Statement stmt = null;
    private ResultSet rs = null;
    private PreparedStatement pst=null;

  void  DbPerpus() {
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            con = DriverManager.getConnection(jdbcURL, user, password);
            JOptionPane.showMessageDialog(null, "Success");
            stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex);
        }
    }

    public DbPerpus(String usr, String pss) {
        user = usr;
        password = pss;
        DbPerpus();
    }

   ArrayList<Peminjam> getPeminjam() throws SQLException {
        Dosen dosen;
        Mahasiswa mahasiswa;
        Umum umum;
        ArrayList<Peminjam> peminjamList = new ArrayList<>();
        stmt = null;
        rs = null;
        stmt = con.createStatement();
        rs = stmt.executeQuery("SELECT * FROM DOSEN");
        if (rs != null) {
            while (rs.next()) {
                //String nip, String idPeminjaman, String nama, String alamat, int maxPinjam
                dosen = new Dosen(
                        rs.getString("ID_DOSEN"),
                        rs.getString("NPP"),
                        rs.getString("NAMA_DSN"),
                        rs.getString("ALAMAT_DSN"),
                        rs.getInt("JUMLAH_PINJAM_DSN")
                );
                peminjamList.add(dosen);
            }
        }
        rs = null;
        rs = stmt.executeQuery("SELECT * FROM MAHASISWA");
        if (rs != null) {
            while (rs.next()) {
                //String nim, String idPeminjaman, String nama, String alamat, int maxPinjam
                mahasiswa = new Mahasiswa(
                        rs.getString("ID_MAHASISWA"),
                        rs.getString("NIM"),
                        rs.getString("NAMA_MHS"),
                        rs.getString("ALAMAT_MHS"),
                        rs.getInt("JUMLAH_PINJAM_MHS")
                );
                peminjamList.add(mahasiswa);
            }
        }
        rs = null;
        rs = stmt.executeQuery("SELECT * FROM UMUM");
        if (rs != null) {
            while (rs.next()) {
                //String nik, String idPeminjaman, String nama, String alamat, int maxPinjam
                umum = new Umum(
                        rs.getString("ID_U"),
                        rs.getString("NIK"),
                        rs.getString("NAMA_U"),
                        rs.getString("ALAMAT_U"),
                        rs.getInt("JUMLAH_PINJAM_U")
                );
                peminjamList.add(umum);
            }
        }
        return peminjamList;
    }
      int insertDosen(String ID_DSN, String NPP, String NAMA_DSN, String ALAMAT_DSN, int JUMLAH_PINJAM_DSN) {
        String kueri = "INSERT INTO DOSEN VALUES (?,?,?,?,?)";
        pst = null;
        int rq = 0;
        try {
            pst = con.prepareStatement(kueri);
            pst.setString(1, ID_DSN);
            pst.setString(2, NPP);
            pst.setString(3, NAMA_DSN);
            pst.setString(4, ALAMAT_DSN);
            pst.setInt(5, JUMLAH_PINJAM_DSN);
            rq = pst.executeUpdate();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return rq;
    }
    int insertMahasiswa(String ID_MHS, String NIM, String NAMA_MHS, String ALAMAT_MHS, int JUMLAH_PINJAM_MHS) {
        String kueri = "INSERT INTO mahasiswa VALUES (?,?,?,?,?)";
        pst= null;
        int rq = 0;
        try {
            pst = con.prepareStatement(kueri);
            pst.setString(1, ID_MHS);
            pst.setString(2, NIM);
            pst.setString(3, NAMA_MHS);
            pst.setString(4, ALAMAT_MHS);
            pst.setInt(5, JUMLAH_PINJAM_MHS);
            rq = pst.executeUpdate();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return rq;
    }
    int insertUmum(String ID_U, String NIK, String NAMA_U, String ALAMAT_U, int JUMLAH_PINJAM_U) {
        String kueri = "INSERT INTO umum VALUES (?,?,?,?,?)";
        pst = null;
        int rq = 0;
        try {
            pst = con.prepareStatement(kueri);
            pst.setString(1, ID_U);
            pst.setString(2, NIK);
            pst.setString(3, NAMA_U);
            pst.setString(4, ALAMAT_U);
            pst.setInt(5, JUMLAH_PINJAM_U);
            rq = pst.executeUpdate();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return rq;
    }

    ArrayList<Koleksi> getKoleksi() throws SQLException {
        majalah majalah;
        Buku buku;
        Disk disk;
        ArrayList<Koleksi> koleksiList = new ArrayList<>();
        stmt = null;
        rs = null;
        stmt = con.createStatement();
        rs = stmt.executeQuery("SELECT * FROM MAJALAH");
        if (rs != null) {
            while (rs.next()) {
                //String IdKoleksi, String judul, String Penerbit, boolean StatusPinjam, int volume, int seri, String ISSN
                 majalah = new majalah(
                        rs.getString("ID_M"),
                        rs.getString("JUDUL_M"),
                        rs.getString("PENERBIT_M"),
                          rs.getBoolean("STATUS_PINJAM_M"),
                        rs.getInt("VOLUME_M"),
                        rs.getInt("SERI_M"),
                        rs.getString("ISSN_MAJALAH")
                );
                koleksiList.add(majalah);
            }
        }
        rs = null;
        rs = stmt.executeQuery("SELECT * FROM BOOK");
        if (rs != null) {
            while (rs.next()) {
                //String IdKoleksi, String judul, String Penerbit, boolean StatusPinjam, int halaman, String ISBN
                buku = new Buku(
                       rs.getString("ID_B"),
                        rs.getString("JUDUL_B"),
                        rs.getString("PENERBIT_B"),
                          rs.getBoolean("STATUS_PINJAM_B"),
                        rs.getInt("HALAMAN_B"),
                        rs.getString("ISBN_BOOK")
                );
                koleksiList.add(buku);
            }
        }
        rs = null;
        rs = stmt.executeQuery("SELECT * FROM CD");
        if (rs != null) {
            while (rs.next()) {
                //String IdKoleksi, String judul, String Penerbit, boolean StatusPinjam,String format, String ISBN
                disk = new Disk(
                       rs.getString("ID_D"),
                        rs.getString("JUDUL_D"),
                        rs.getString("PENERBIT_D"),
                          rs.getBoolean("STATUS_PINJAM_D"),
                        rs.getString("FORMAT_D"),
                        rs.getString("ISBN_DISK")
                );
                koleksiList.add(disk);
            }
        }
        return koleksiList;
    }
    int insertMajalah(String ID_M, String JUDUL_M, String PENERBIT_M, boolean STATUS_PINJAM_M, int VOLUME_M, int SERI_M, String ISSN_MAJALAH) {
        String kueri = "INSERT INTO MAJALAH VALUES (?,?,?,?,?,?,?)";
        pst = null;
        int rq = 0;
        try {
            pst = con.prepareStatement(kueri);
            pst.setString(1, ID_M);
            pst.setString(2, JUDUL_M);
            pst.setString(3, PENERBIT_M);
            pst.setBoolean(4, STATUS_PINJAM_M);
            pst.setInt(5, VOLUME_M);
            pst.setInt(6, SERI_M);
            pst.setString(7, ISSN_MAJALAH);
            rq = pst.executeUpdate();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return rq;
    }
    int insertBuku(String ID_B, String JUDUL_B, String PENERBIT_B, boolean STATUS_PINJAM_B, int HALAMAN_B, String ISBN_BOOK) {
        String kueri = "INSERT INTO BOOK VALUES (?,?,?,?,?,?)";
        pst = null;
        int rq = 0;
        try {
            pst = con.prepareStatement(kueri);
            pst.setString(1, ID_B);
            pst.setString(2, JUDUL_B);
            pst.setString(3, PENERBIT_B);
            pst.setBoolean(4, STATUS_PINJAM_B);
            pst.setInt(5, HALAMAN_B);
            pst.setString(6, ISBN_BOOK);
            rq = pst.executeUpdate();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return rq;
    }
    int insertDisk(String ID_D, String JUDUL_D, String PENERBIT_D, boolean STATUS_PINJAM_D, String FORMAT_D, String ISBN_DISK) {
        String kueri = "INSERT INTO CD VALUES (?,?,?,?,?,?)";
        pst = null;
        int rq = 0;
        try {
            pst = con.prepareStatement(kueri);
            pst.setString(1, ID_D);
            pst.setString(2, JUDUL_D);
            pst.setString(3, PENERBIT_D);
            pst.setBoolean(4, STATUS_PINJAM_D);
            pst.setString(5, FORMAT_D);
            pst.setString(6, ISBN_DISK);
            rq = pst.executeUpdate();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return rq;
    }
}
