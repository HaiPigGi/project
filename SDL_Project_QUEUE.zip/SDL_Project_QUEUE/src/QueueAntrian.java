
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.NoSuchElementException;
import java.util.Queue;

public class QueueAntrian {

    private static int front, rear, Size;
    private static Object[] elemen;
    
    public QueueAntrian(){
        elemen = new Object[5];
        front=0;
    }
    public QueueAntrian(int ukuran) {
        front = 0;
        rear = 0;
        elemen = new Object[ukuran];
    }

    // insert an element into the elemen
    static Boolean enqueue(Object item) {
        if (Size < elemen.length) {
            elemen[rear] = item;
            if (rear==elemen.length-1) {
                rear=0;
            }
            else{
                rear++;
            }
            Size++;
            return true;
        }else{
            return false;
        }
    }

    static Object dequeue() {
        Object x = 0;
        if (!isEmpty()) {
            x = elemen[front];
            if (front == elemen.length - 1) {
                front = 0;
            } else {
                front++;
            }
            Size--;
        }
        else {
            System.out.printf("Antrian Kosong.");
            throw new NoSuchElementException();
        }
        return x;
    }

    static boolean isEmpty() {
        if (Size==0) {
            return true;
        }else{
            return false;
        }
    }

    static int size() {
        return Size;
    }
    public void Cetak() {
        for (int i = front; i <=rear; i++) {
            System.out.println(elemen[i]);
        }
        if (isEmpty()) {
            System.out.println("Antrian Telah Kosong");
        }
    }

}
